#This scripts fits the bivariate regression model using alternative two (iNim2-RW)

# load packages
library(myphdthesis)
library(INLA)
library(inlabru)
library(nimble)
ii = 0

#load data
load("bivariateRegression/data_for_simulations.RData")

# Define conditional model to be fitted using INLA
fit.inlaAlt1 <- function(x ,
                        y ,
                        beta,
                        interInModel,
                        family
){
  ii  <- get("ii",envir =  parent.frame())
  ii <- assign("ii",ii+1,envir = parent.frame())
  print(ii)
  data <- list(y=y, x=x)
  data$oset = data$x %*% matrix(beta, ncol = 1)

  if(interInModel == 1){
    formula = y ~  1 + offset(data$oset)
  }else{
    formula = y ~  - 1 + offset(data$oset)
  }

  res = INLA::inla(formula,
                   data = data,
                   family = family,
                   verbose=FALSE,
                   control.fixed = list(prec.intercept = 0.001),
                   control.compute = list(config = TRUE),
                   control.predictor = list(compute = TRUE))

  #generate samples
  samples <- inla.posterior.sample(1, res)
  fitted_values <- samples[[1]]$latent[grepl("Predictor",rownames(samples[[1]]$latent) ),1]
  if(interInModel == 1){
    intercept = samples[[1]]$latent[grepl("Intercept",rownames(samples[[1]]$latent) ),1]
  }else{
    intercept = 1
  }
  precision <-  inla.hyperpar.sample(1, res)
  ret <- cbind(intercept, c(precision), fitted_values)
  return(ret)
}

nimbleINLAalt1 <- nimble::nimbleRcall(
  prototype = function(
    x=double(2), #x is a matrix
    y=double(1), #y is a vector
    beta=double(1), # beta is a vector
    interInModel = double(0, default = 1),
    family = character(0, default = "gaussian")
  ) {},
  returnType = double(2), # outcome is a vector
  Rfun = 'fit.inlaAlt1'
)

# Nimble code
code <- nimble::nimbleCode({
  #Prior for beta1 and beta2
  for(i in 1:2){
    beta[i] ~ dnorm(0, tau = 0.01)
  }

  #Fitting the inla with the simulated parameters
  inla.res[1:N, 1:3] <- nimbleINLAalt1(x[1:N,1:2],y_obs[1:N],beta[1:2],inter)

  sigma <- inla.res[1,2]
  linpred[1:N] <-  intercept + beta[1]*x[1:N,1]  + beta[2]*x[1:N,2]


  #Bivariate linear model specification
  for(i in 1:N){
    y[i] ~ dnorm(linpred[i], tau=sigma)
  }

 # tau <- sigma
  intercept <- inla.res[1,1]
})


data = bivariateSims
idm_data <- list(y=data$y,
                 x = data$x,
                 y_obs=data$y,
                 inter = 1)

constants = list(N = length(data$y),
                 mu = c(0,0),
                 precision_matrix = diag(5,2),
                 fam = "gaussian")

inits <-  function(){list(beta =c(0,0)
)
}

# Fit the INLA within Nimble model
samplers <- c('RW_block')
inlaNimBivariateAlt <- list()
for(i in seq_along(samplers)){
inlaNimBivariateAlt[[i]] = INLAWiNim(data = bivariateSims,
                                   code = code,
                              modelData = idm_data,
                              modelConstants = constants,
                              modelInits = inits,
                              fam = "gaussian",
                              mcmcSamplerChange = TRUE,
                              parametersForSamplerChange = "beta",
                              newSampler = samplers[i],
                              newSamplerControl = list(scale = 0.75),
                              mcmcConfiguration =  list(n.chains = 1,
                                                        n.iterations = 100500,
                                                        n.burnin = 50500,
                                                        n.thin = 5,
                                                        setSeed = TRUE,
                                                        samples=TRUE,
                                                        samplesAsCodaMCMC = TRUE,
                                                        summary = TRUE,
                                                        WAIC = FALSE))
}

save(inlaNimBivariateAlt, file = "bivariateRegression/inlaWithNimbleAlt/inlaNimBivariateRegressionAlt.RData")


