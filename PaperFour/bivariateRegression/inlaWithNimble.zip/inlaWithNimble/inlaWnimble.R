#This scripts fits the bivariate regression model using alternative one (iNim-RW)
#and MCMC

# Bivariate regression
#Simulation studies

# load packages
library(inlamcmcnimble)
library(INLA)
library(inlabru)
library(nimble)

# load data
load("bivariateRegression/data_for_simulations.RData")

# Nimble code
code <- nimble::nimbleCode({

  #Prior for beta1 and beta2
  for(i in 1:2){
    beta[i] ~ dnorm(0, tau = 0.01)
  }

  # Prior for intercept
  a ~ dunif(-1000, 1000)

# linear predictor
  for(i in 1:N){
  linpred[i] <-  a + beta[1]*x[i, 1] + beta[2]*x[i, 2]
  }

  #Bivariate linear model specification
  for(i in 1:N){
    y[i] ~ dnorm(linpred[i], tau= sigma)
  }

# Prior for precision parameter
  sigma ~ dgamma(1,0.00005)
})

# Parameterization
data = bivariateSims

#data
idm_data <- list(y=data$y,
                 x = data$x,
                 y_obs=data$y,
                 inter = 1)

# constants
constants = list(N = length(data$y),
                 mu = c(0,0),
                 precision_matrix = diag(5,2),
                 fam = "gaussian")

# Initial values
inits <-  function(){list(beta =c(0,0),
                          a = 1,
                          sigma = 1
)
}

initsList <- inits()

# INLA function
fit.inla <- function(x , # covariates (a matrix)
                     y , # a character showing which covariate is a vector
                     beta, # vars with MCMC
                     fixedVals, # vars with INLA
                     family # what is the parametric family
){

  # set the data and the offset
  data <- list(y=y,
               x1=x[,1],
               x2 = x[,2])
  data$oset = beta[1]*data$x1 + beta[2]*data$x2
#try and check the offset
  formula = y ~  1 + offset(data$oset)
  # Fit INLA for Bayes average of the pars
  res = INLA::inla(formula,
                   data = data,
                   family = family,
                   verbose=FALSE,
                   control.fixed = list(prec.intercept = 0.001),
                   control.compute = list(config = TRUE),
                   control.predictor = list(compute = TRUE))

  # conditional marginal log-likelihood
  fitted_values = c(res$mlik[1,1])

  #generate samples
  samples <- inla.posterior.sample(1, res)
  intercept = samples[[1]]$latent[grepl("Intercept",rownames(samples[[1]]$latent) ),1]
  precision <-  inla.hyperpar.sample(1, res)

  ret <- data.frame(mld = fitted_values,
                    intercept,
                    c(precision),
                    row.names = NULL)

  colnames(ret) <- c("mld", fixedVals)

  ret <- as.matrix(ret)
  return(ret)
}

# Set up the R function for use in INLA
nimbleINLA <- nimble::nimbleRcall(
  prototype = function(
    x=double(2), #x is a matrix
    y=double(1), #y is a vector
    beta=double(1), # beta is a vector
    fixedVals = character(1, default = c("a", "sigma")),
    family = character(0, default = "gaussian")
  ) {},
  returnType = double(2), # outcome is a vector
  Rfun = 'fit.inla'
)

# run the function
samplers <- c("RW_INLA_block", "AFSS_INLA_block", "RW_block")
inlaMCMCtype <- c("inlamcmc", "inlamcmc", "mcmc")

inlaNimBivariate <- list()
for(i in seq_along(samplers)){
  inlaNimBivariate <- INLAWiNimDataGenerating(data = c("y"),
                        covariate = data$x,
                        code = code,
                        family = "gaussian",
                        modelData = idm_data,
                        modelConstants = constants,
                        modelInits = inits,
                        nimbleINLA = nimbleINLA,
                        inlaMCMC = inlaMCMCtype[i],
                        inlaMCsampler = samplers[i],
                        samplerControl = list(scale = 0.75,
                                              #propCov = diag((1/0.75^2), 2),
                                              adaptive = FALSE,
                                              sliceMaxSteps = 30),
                        parametersToMonitor = list(mcmc = c("beta"),
                                                   inla = c("a", "sigma")),
                        mcmcConfiguration = list(n.chains = 1,
                                                 n.iterations = 100500,
                                                 n.burnin = 50500,
                                                 n.thin = 5,
                                                 setSeed = TRUE,
                                                 samples=TRUE,
                                                 samplesAsCodaMCMC = TRUE,
                                                 summary = TRUE,
                                                 WAIC = FALSE)
                        )
  save(inlaNimBivariate, file = paste0("bivariateRegression/inlaWithNimble/inlaNimBivariateRegression",i,".RData"))

}

